"""
PHISH_DETECT — Standalone Phishing Website Detector
====================================================
A self-contained Python web app. No external dependencies beyond Flask.

Install:  pip install flask
Run:      python phish_detect_standalone.py
Open:     http://localhost:5000
"""

from flask import Flask, request, jsonify, render_template_string
import re
import json
import sqlite3
import os
from urllib.parse import urlparse, parse_qs
from datetime import datetime

# ─────────────────────────────────────────────────────────────
# DATABASE SETUP  (SQLite — no server required)
# ─────────────────────────────────────────────────────────────

DB_PATH = "phish_detect.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS analyses (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            url         TEXT    NOT NULL,
            risk_score  INTEGER NOT NULL,
            verdict     TEXT    NOT NULL,
            indicators  TEXT    NOT NULL,
            analyzed_at TEXT    NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.commit()
    conn.close()

# ─────────────────────────────────────────────────────────────
# PHISHING DETECTION ENGINE
# ─────────────────────────────────────────────────────────────

SUSPICIOUS_TLDS = [
    ".xyz", ".tk", ".ml", ".ga", ".cf", ".gq",
    ".pw", ".top", ".click", ".link", ".work", ".party"
]

PHISHING_KEYWORDS = [
    "login", "signin", "sign-in", "account", "verify", "verification",
    "secure", "update", "confirm", "banking", "paypal", "amazon", "apple",
    "microsoft", "google", "facebook", "instagram", "netflix", "wellsfargo",
    "bankofamerica", "chase", "citibank", "password", "credential", "wallet",
]

POPULAR_DOMAINS = [
    "paypal", "amazon", "google", "facebook", "apple",
    "microsoft", "netflix", "instagram", "twitter", "linkedin"
]


def analyze_url(raw_url: str) -> dict:
    """
    Run 12 heuristic checks on a URL and return a risk score,
    verdict (safe / suspicious / phishing), and per-indicator breakdown.
    """
    if not raw_url.startswith("http"):
        raw_url = "http://" + raw_url

    try:
        parsed     = urlparse(raw_url)
        hostname   = parsed.hostname.lower() if parsed.hostname else ""
        pathname   = parsed.path.lower()
        params     = parse_qs(parsed.query)
    except Exception:
        return {
            "riskScore": 80,
            "verdict": "phishing",
            "indicators": [{
                "name": "Invalid URL",
                "description": "The URL could not be parsed as a valid web address.",
                "severity": "high",
                "triggered": True
            }]
        }

    indicators = []
    domain_part = re.sub(r"^www\.", "", hostname)

    # 1. HTTPS check
    indicators.append({
        "name": "No HTTPS",
        "description": "The URL does not use a secure HTTPS connection.",
        "severity": "medium",
        "triggered": parsed.scheme != "https"
    })

    # 2. IP address as hostname
    is_ip = bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", hostname))
    indicators.append({
        "name": "IP Address as Host",
        "description": "Uses a raw IP address instead of a domain name — a common phishing tactic.",
        "severity": "high",
        "triggered": is_ip
    })

    # 3. Suspicious TLD
    has_suspicious_tld = any(hostname.endswith(tld) for tld in SUSPICIOUS_TLDS)
    indicators.append({
        "name": "Suspicious TLD",
        "description": "Uses a TLD commonly associated with free or disposable phishing domains.",
        "severity": "medium",
        "triggered": has_suspicious_tld
    })

    # 4. Phishing keyword in domain
    has_keyword = any(kw in domain_part for kw in PHISHING_KEYWORDS)
    indicators.append({
        "name": "Brand / Phishing Keyword in Domain",
        "description": "The domain contains a known brand name or phishing keyword.",
        "severity": "high",
        "triggered": has_keyword
    })

    # 5. @ symbol in URL (redirect trick)
    indicators.append({
        "name": "@ Symbol in URL",
        "description": "Browsers may use @ to redirect to a different host than displayed.",
        "severity": "high",
        "triggered": "@" in raw_url
    })

    # 6. Excessive subdomains
    subdomain_count = len(hostname.split(".")) - 2
    indicators.append({
        "name": "Excessive Subdomains",
        "description": "Too many subdomains used to add fake legitimacy.",
        "severity": "medium",
        "triggered": subdomain_count > 3
    })

    # 7. Unusually long URL
    indicators.append({
        "name": "Unusually Long URL",
        "description": "Excessively long URLs can obscure the true destination.",
        "severity": "low",
        "triggered": len(raw_url) > 100
    })

    # 8. Double dots in domain
    indicators.append({
        "name": "Double Dots in Domain",
        "description": "Consecutive dots in the domain are abnormal and indicate manipulation.",
        "severity": "medium",
        "triggered": ".." in hostname
    })

    # 9. Excessive hyphens
    indicators.append({
        "name": "Excessive Hyphens in Domain",
        "description": "Many hyphens used to mimic legitimate URLs (e.g. secure-paypal-login.com).",
        "severity": "medium",
        "triggered": hostname.count("-") >= 3
    })

    # 10. Suspicious path keywords
    path_keywords = ["login","signin","verify","confirm","account","password","update","secure","banking"]
    indicators.append({
        "name": "Suspicious Path Keywords",
        "description": "Path contains keywords like login, verify, or confirm.",
        "severity": "low",
        "triggered": any(kw in pathname for kw in path_keywords)
    })

    # 11. Redirect parameters
    redirect_params = {"redirect", "url", "goto", "next", "return"}
    indicators.append({
        "name": "Redirect Parameter",
        "description": "URL contains redirect= / next= — may forward to a malicious site.",
        "severity": "medium",
        "triggered": bool(redirect_params & set(params.keys()))
    })

    # 12. Typosquatting (character substitutions o→0, a→4, i→1, e→3)
    def has_typosquat(brand):
        if brand in domain_part:
            return False  # caught by keyword check already
        return (
            brand.replace("a","4") in domain_part or
            brand.replace("o","0") in domain_part or
            brand.replace("i","1") in domain_part or
            brand.replace("e","3") in domain_part
        )

    indicators.append({
        "name": "Possible Typosquatting",
        "description": "Character substitutions detected (e.g. amaz0n, payp4l, netf1ix).",
        "severity": "high",
        "triggered": any(has_typosquat(b) for b in POPULAR_DOMAINS)
    })

    # ── Score ──────────────────────────────────────────────────
    weights    = {"high": 25, "medium": 12, "low": 6}
    raw_score  = sum(weights[i["severity"]] for i in indicators if i["triggered"])
    risk_score = min(100, raw_score)

    if   risk_score >= 50: verdict = "phishing"
    elif risk_score >= 20: verdict = "suspicious"
    else:                  verdict = "safe"

    return {"riskScore": risk_score, "verdict": verdict, "indicators": indicators}


# ─────────────────────────────────────────────────────────────
# HTML / CSS / JS  FRONTEND  (single-page, embedded)
# ─────────────────────────────────────────────────────────────

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>PHISH_DETECT</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    /* ── Reset & base ───────────────────────────────────────── */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg:          #050d1a;
      --bg2:         #091220;
      --card:        #0c1627;
      --border:      #1e2d45;
      --text:        #e8f0fe;
      --muted:       #5a7098;
      --primary:     #3b82f6;
      --red:         #ef4444;
      --amber:       #f59e0b;
      --green:       #22c55e;
      --font-sans:   'Inter', sans-serif;
      --font-mono:   'JetBrains Mono', monospace;
      --radius:      8px;
    }

    html, body { height: 100%; background: var(--bg); color: var(--text); font-family: var(--font-sans); }

    /* ── Layout ─────────────────────────────────────────────── */
    .shell         { display: flex; min-height: 100vh; }
    .sidebar       { width: 240px; background: var(--bg2); border-right: 1px solid var(--border);
                     display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; z-index: 10; }
    .sidebar-logo  { height: 64px; display: flex; align-items: center; gap: 10px;
                     padding: 0 20px; border-bottom: 1px solid var(--border); }
    .sidebar-logo span { font-family: var(--font-mono); font-weight: 700; font-size: 15px; letter-spacing: -0.5px; }
    .sidebar-logo svg  { color: var(--primary); flex-shrink: 0; }
    .sidebar-label { font-family: var(--font-mono); font-size: 10px; color: var(--muted);
                     padding: 20px 20px 8px; text-transform: uppercase; letter-spacing: 1px; }
    .nav-item      { display: flex; align-items: center; gap: 10px; padding: 9px 16px; margin: 2px 8px;
                     border-radius: var(--radius); cursor: pointer; font-size: 13px; font-weight: 500;
                     color: var(--muted); transition: all .15s; text-decoration: none; }
    .nav-item:hover{ background: rgba(255,255,255,.04); color: var(--text); }
    .nav-item.active { background: rgba(59,130,246,.12); color: var(--primary); }
    .nav-item svg  { flex-shrink: 0; opacity: .7; }
    .nav-item.active svg { opacity: 1; }
    .sidebar-footer{ margin-top: auto; padding: 16px; border-top: 1px solid var(--border);
                     display: flex; align-items: center; gap: 10px; }
    .status-dot    { width: 8px; height: 8px; border-radius: 50%; background: var(--green);
                     animation: pulse 2s infinite; flex-shrink: 0; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
    .status-label  { font-family: var(--font-mono); font-size: 11px; color: var(--muted); }

    .main          { flex: 1; margin-left: 240px; padding: 40px 48px; max-width: 900px; }

    /* ── Page titles ─────────────────────────────────────────── */
    .page          { display: none; }
    .page.active   { display: block; }
    h1             { font-family: var(--font-mono); font-size: 28px; font-weight: 700; margin-bottom: 8px; }
    .subtitle      { font-family: var(--font-mono); font-size: 12px; color: var(--muted); margin-bottom: 32px; max-width: 560px; line-height: 1.6; }

    /* ── Card ────────────────────────────────────────────────── */
    .card          { background: var(--card); border: 1px solid var(--border); border-radius: var(--radius);
                     padding: 24px; margin-bottom: 24px; }
    .card-title    { font-family: var(--font-mono); font-size: 14px; font-weight: 600; margin-bottom: 4px;
                     display: flex; align-items: center; gap: 8px; }
    .card-desc     { font-family: var(--font-mono); font-size: 11px; color: var(--muted); margin-bottom: 20px; }

    /* ── URL Input form ──────────────────────────────────────── */
    .input-row     { display: flex; gap: 12px; align-items: flex-start; }
    .url-input     { flex: 1; background: rgba(255,255,255,.04); border: 1px solid var(--border);
                     border-radius: var(--radius); padding: 0 16px; height: 48px;
                     font-family: var(--font-mono); font-size: 13px; color: var(--text); outline: none; }
    .url-input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(59,130,246,.15); }
    .url-input::placeholder { color: var(--muted); }
    .btn           { height: 48px; padding: 0 28px; border-radius: var(--radius); border: none;
                     font-family: var(--font-mono); font-size: 13px; font-weight: 600; cursor: pointer;
                     background: var(--primary); color: #fff; letter-spacing: .5px;
                     display: flex; align-items: center; gap: 8px; white-space: nowrap; transition: opacity .15s; }
    .btn:hover     { opacity: .85; }
    .btn:disabled  { opacity: .5; cursor: not-allowed; }
    .err-msg       { font-family: var(--font-mono); font-size: 11px; color: var(--red); margin-top: 6px; }

    /* ── Result card ─────────────────────────────────────────── */
    .result-card            { border-radius: var(--radius); padding: 24px; margin-bottom: 24px; border: 1px solid; animation: fadeUp .3s ease; }
    .result-card.phishing   { background: rgba(239,68,68,.07);  border-color: rgba(239,68,68,.25); }
    .result-card.suspicious { background: rgba(245,158,11,.07); border-color: rgba(245,158,11,.25); }
    .result-card.safe       { background: rgba(34,197,94,.07);  border-color: rgba(34,197,94,.25); }
    @keyframes fadeUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }

    .result-header         { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
    .result-title          { font-family: var(--font-mono); font-size: 18px; font-weight: 700;
                             display: flex; align-items: center; gap: 10px; }
    .result-url            { font-family: var(--font-mono); font-size: 11px; color: var(--muted);
                             margin-top: 6px; word-break: break-all; max-width: 480px; }
    .verdict-badge         { font-family: var(--font-mono); font-size: 12px; font-weight: 700;
                             text-transform: uppercase; letter-spacing: 1px; padding: 5px 12px;
                             border-radius: var(--radius); border: 1px solid; }
    .verdict-badge.phishing   { color: var(--red);   border-color: rgba(239,68,68,.4); }
    .verdict-badge.suspicious { color: var(--amber); border-color: rgba(245,158,11,.4); }
    .verdict-badge.safe       { color: var(--green); border-color: rgba(34,197,94,.4); }

    /* Score bar */
    .score-row     { display: flex; justify-content: space-between; font-family: var(--font-mono); font-size: 12px; margin-bottom: 8px; }
    .score-label   { color: var(--muted); }
    .score-value   { font-weight: 700; }
    .score-value.phishing   { color: var(--red); }
    .score-value.suspicious { color: var(--amber); }
    .score-value.safe       { color: var(--green); }
    .progress-track { height: 6px; background: rgba(255,255,255,.07); border-radius: 3px; overflow: hidden; margin-bottom: 24px; }
    .progress-fill  { height: 100%; border-radius: 3px; transition: width .5s ease; }
    .progress-fill.phishing   { background: var(--red); }
    .progress-fill.suspicious { background: var(--amber); }
    .progress-fill.safe       { background: var(--green); }

    /* Indicators */
    .indicators-title { font-family: var(--font-mono); font-size: 11px; font-weight: 600; letter-spacing: 1.5px;
                        color: var(--muted); text-transform: uppercase; border-bottom: 1px solid var(--border);
                        padding-bottom: 10px; margin-bottom: 14px; }
    .indicator-row  { display: flex; gap: 14px; align-items: flex-start; padding: 12px 14px;
                      border-radius: 6px; background: rgba(255,255,255,.025); border: 1px solid var(--border);
                      margin-bottom: 8px; }
    .indicator-icon { flex-shrink: 0; margin-top: 2px; }
    .indicator-name { font-family: var(--font-mono); font-size: 12px; font-weight: 600; }
    .indicator-desc { font-family: var(--font-mono); font-size: 11px; color: var(--muted); margin-top: 3px; line-height: 1.5; }
    .indicator-desc.untriggered { text-decoration: line-through; opacity: .4; }
    .sev-badge      { font-family: var(--font-mono); font-size: 10px; font-weight: 600; padding: 2px 7px;
                      border-radius: 4px; border: 1px solid; margin-left: auto; flex-shrink: 0; align-self: flex-start; }
    .sev-high   { color: var(--red);   border-color: rgba(239,68,68,.35); }
    .sev-medium { color: var(--amber); border-color: rgba(245,158,11,.35); }
    .sev-low    { color: var(--primary); border-color: rgba(59,130,246,.35); }

    /* ── History table ───────────────────────────────────────── */
    .history-table  { width: 100%; }
    .history-row    { display: flex; gap: 12px; align-items: center; padding: 14px 16px;
                      border-bottom: 1px solid var(--border); transition: background .1s; }
    .history-row:last-child { border-bottom: none; }
    .history-row:hover      { background: rgba(255,255,255,.02); }
    .history-icon   { width: 38px; height: 38px; flex-shrink: 0; border-radius: 7px; border: 1px solid;
                      display: flex; align-items: center; justify-content: center; }
    .history-icon.phishing   { border-color: rgba(239,68,68,.3); background: rgba(239,68,68,.06); }
    .history-icon.suspicious { border-color: rgba(245,158,11,.3); background: rgba(245,158,11,.06); }
    .history-icon.safe       { border-color: rgba(34,197,94,.3); background: rgba(34,197,94,.06); }
    .history-url    { font-family: var(--font-mono); font-size: 12px; white-space: nowrap;
                      overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; }
    .history-meta   { font-family: var(--font-mono); font-size: 10px; color: var(--muted); margin-top: 3px; }
    .history-score  { font-family: var(--font-mono); font-size: 12px; font-weight: 600; flex-shrink: 0; }
    .col-phishing   { color: var(--red); }
    .col-suspicious { color: var(--amber); }
    .col-safe       { color: var(--green); }
    .empty-state    { padding: 60px 0; text-align: center; color: var(--muted);
                      font-family: var(--font-mono); font-size: 12px; }

    /* ── Spinner ─────────────────────────────────────────────── */
    .spinner { width:16px; height:16px; border:2px solid rgba(255,255,255,.3);
               border-top-color:#fff; border-radius:50%; animation: spin .6s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* ── Responsive ──────────────────────────────────────────── */
    @media (max-width: 700px) {
      .sidebar { transform: translateX(-100%); }
      .main    { margin-left: 0; padding: 24px 20px; }
    }
  </style>
</head>
<body>
<div class="shell">

  <!-- ── Sidebar ─────────────────────────────────────────── -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
      <span>PHISH_DETECT</span>
    </div>

    <div class="sidebar-label">Modules</div>

    <a class="nav-item active" id="nav-analyzer" onclick="showPage('analyzer')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>
      </svg>
      Analyzer
    </a>

    <a class="nav-item" id="nav-history" onclick="showPage('history')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>
      History
    </a>

    <div class="sidebar-footer">
      <div class="status-dot"></div>
      <span class="status-label">SYSTEM ONLINE</span>
    </div>
  </aside>

  <!-- ── Main ────────────────────────────────────────────── -->
  <main class="main">

    <!-- ANALYZER PAGE -->
    <div class="page active" id="page-analyzer">
      <h1>Threat Analyzer</h1>
      <p class="subtitle">Enter a suspected phishing URL. The engine analyzes the domain, TLS, content, and reputation signals to determine the threat level.</p>

      <div class="card">
        <div class="card-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
            <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
          </svg>
          Target URL
        </div>
        <div class="card-desc">Awaiting input for analysis</div>

        <div class="input-row">
          <input
            class="url-input"
            id="url-input"
            type="text"
            placeholder="https://suspicious-domain.com/login"
            onkeydown="if(event.key==='Enter') scanUrl()"
          />
          <button class="btn" id="scan-btn" onclick="scanUrl()">
            <span id="btn-text">SCAN</span>
            <svg id="btn-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
            </svg>
            <div class="spinner" id="btn-spinner" style="display:none"></div>
          </button>
        </div>
        <div class="err-msg" id="url-error"></div>
      </div>

      <div id="result-area"></div>
    </div>

    <!-- HISTORY PAGE -->
    <div class="page" id="page-history">
      <h1>Analysis History</h1>
      <p class="subtitle">Log of recent domain scans. Review past verdicts and threat indicators.</p>

      <div class="card" style="padding:0">
        <div style="padding:20px 24px; border-bottom:1px solid var(--border)">
          <div class="card-title">Scan Registry</div>
          <div class="card-desc" style="margin-bottom:0">Chronological record of analyzed URLs</div>
        </div>
        <div id="history-list" class="history-table">
          <div class="empty-state">Loading...</div>
        </div>
      </div>
    </div>

  </main>
</div>

<script>
// ── Navigation ────────────────────────────────────────────────
function showPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.getElementById('nav-' + page).classList.add('active');
  if (page === 'history') loadHistory();
}

// ── Icons ─────────────────────────────────────────────────────
function iconFor(verdict) {
  if (verdict === 'phishing')
    return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  if (verdict === 'suspicious')
    return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--amber)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>`;
}

function smallIconFor(verdict) {
  if (verdict === 'phishing')
    return `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  if (verdict === 'suspicious')
    return `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--amber)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
  return `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>`;
}

function indicatorIcon(triggered, severity) {
  if (!triggered)
    return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.2)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
  const color = severity === 'high' ? 'var(--red)' : severity === 'medium' ? 'var(--amber)' : 'var(--primary)';
  return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
}

// ── Scan ──────────────────────────────────────────────────────
async function scanUrl() {
  const input = document.getElementById('url-input');
  const errEl = document.getElementById('url-error');
  const btn   = document.getElementById('scan-btn');
  const url   = input.value.trim();

  errEl.textContent = '';

  if (!url) { errEl.textContent = 'Please enter a URL.'; return; }
  if (!/^https?:\\/\\//i.test(url) && !url.includes('.')) {
    errEl.textContent = 'Please enter a valid URL (e.g. https://example.com)';
    return;
  }

  // Loading state
  btn.disabled = true;
  document.getElementById('btn-text').textContent = 'ANALYZING';
  document.getElementById('btn-arrow').style.display = 'none';
  document.getElementById('btn-spinner').style.display = 'block';

  try {
    const res  = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const data = await res.json();
    if (!res.ok) { errEl.textContent = data.error || 'Analysis failed.'; return; }
    renderResult(data);
  } catch(e) {
    errEl.textContent = 'Network error. Is the server running?';
  } finally {
    btn.disabled = false;
    document.getElementById('btn-text').textContent = 'SCAN';
    document.getElementById('btn-arrow').style.display = 'block';
    document.getElementById('btn-spinner').style.display = 'none';
  }
}

function renderResult(data) {
  const v = data.verdict;
  const colorVar = v === 'phishing' ? 'var(--red)' : v === 'suspicious' ? 'var(--amber)' : 'var(--green)';

  const indicatorsHtml = data.indicators.map(ind => {
    const sevBadge = ind.triggered
      ? `<span class="sev-badge sev-${ind.severity}">${ind.severity}</span>`
      : '';
    return `
      <div class="indicator-row">
        <div class="indicator-icon">${indicatorIcon(ind.triggered, ind.severity)}</div>
        <div style="flex:1;min-width:0">
          <div class="indicator-name">${ind.name}</div>
          <div class="indicator-desc ${ind.triggered ? '' : 'untriggered'}">${ind.description}</div>
        </div>
        ${sevBadge}
      </div>`;
  }).join('');

  document.getElementById('result-area').innerHTML = `
    <div class="result-card ${v}">
      <div class="result-header">
        <div>
          <div class="result-title">${iconFor(v)} Analysis Report</div>
          <div class="result-url">${escHtml(data.url)}</div>
        </div>
        <div class="verdict-badge ${v}">${v}</div>
      </div>

      <div class="score-row">
        <span class="score-label">THREAT SCORE</span>
        <span class="score-value ${v}">${data.riskScore} / 100</span>
      </div>
      <div class="progress-track">
        <div class="progress-fill ${v}" style="width:${data.riskScore}%"></div>
      </div>

      <div class="indicators-title">Detected Indicators</div>
      ${indicatorsHtml}
    </div>`;
}

// ── History ───────────────────────────────────────────────────
async function loadHistory() {
  const el = document.getElementById('history-list');
  el.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const res  = await fetch('/api/history');
    const data = await res.json();
    if (!data.length) {
      el.innerHTML = '<div class="empty-state">No records yet. Scan a URL in the Analyzer to get started.</div>';
      return;
    }
    el.innerHTML = data.map(r => {
      const v = r.verdict;
      return `
        <div class="history-row">
          <div class="history-icon ${v}">${smallIconFor(v)}</div>
          <div style="flex:1;min-width:0">
            <div class="history-url">${escHtml(r.url)}</div>
            <div class="history-meta">${r.analyzed_at} &nbsp;·&nbsp; Score: <span class="col-${v}">${r.risk_score}</span></div>
          </div>
          <div class="verdict-badge ${v}" style="font-size:10px;padding:3px 9px">${v}</div>
        </div>`;
    }).join('');
  } catch(e) {
    el.innerHTML = '<div class="empty-state" style="color:var(--red)">Failed to load history.</div>';
  }
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>"""


# ─────────────────────────────────────────────────────────────
# FLASK APP  (API routes + serve the HTML shell)
# ─────────────────────────────────────────────────────────────

app = Flask(__name__)

@app.route("/")
def index():
    return render_template_string(HTML)

@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    body = request.get_json(silent=True) or {}
    url  = (body.get("url") or "").strip()
    if not url:
        return jsonify({"error": "URL is required"}), 400

    result = analyze_url(url)

    conn = get_db()
    conn.execute(
        "INSERT INTO analyses (url, risk_score, verdict, indicators) VALUES (?, ?, ?, ?)",
        (url, result["riskScore"], result["verdict"], json.dumps(result["indicators"]))
    )
    conn.commit()
    row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    row    = conn.execute("SELECT * FROM analyses WHERE id = ?", (row_id,)).fetchone()
    conn.close()

    return jsonify({
        "id":          row["id"],
        "url":         row["url"],
        "riskScore":   row["risk_score"],
        "verdict":     row["verdict"],
        "indicators":  json.loads(row["indicators"]),
        "analyzed_at": row["analyzed_at"],
    })

@app.route("/api/history")
def api_history():
    limit = min(int(request.args.get("limit", 10)), 50)
    conn  = get_db()
    rows  = conn.execute(
        "SELECT * FROM analyses ORDER BY analyzed_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/stats")
def api_stats():
    conn  = get_db()
    rows  = conn.execute("SELECT verdict FROM analyses").fetchall()
    conn.close()
    verdicts = [r["verdict"] for r in rows]
    return jsonify({
        "totalAnalyzed":  len(verdicts),
        "phishingCount":  verdicts.count("phishing"),
        "suspiciousCount": verdicts.count("suspicious"),
        "safeCount":      verdicts.count("safe"),
    })


# ─────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    print("=" * 50)
    print("  PHISH_DETECT — Phishing Website Detector")
    print("  Running at: http://localhost:5000")
    print("=" * 50)
    app.run(debug=True, port=5000)
